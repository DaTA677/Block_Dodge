Thank you for playing Block Dodge!!
To play the game double-click on Block Dodge.exe
The game is simple.. dodge the blocks as long as you can. 
To move your block(red block) use the arrow keys
To dash left or right use the left shift key(the block will dash in the last pressed direction)
To dash up or down use the spacebar (the block will dash in the last pressed direction)
Score is calculated based on how long you survive as well as how many coins(Yellow blocks) you collect.
Can you reach level 4 and score more than 1500 points?
If you lose, the game will freeze. You can press "r" key to restart the game.